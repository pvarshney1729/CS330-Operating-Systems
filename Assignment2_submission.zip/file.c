#include<types.h>
#include<context.h>
#include<file.h>
#include<lib.h>
#include<serial.h>
#include<entry.h>
#include<memory.h>
#include<fs.h>
#include<kbd.h>
#include<pipe.h>


/************************************************************************************/
/***************************Do Not Modify below Functions****************************/
/************************************************************************************/
void free_file_object(struct file *filep)
{
    if(filep)
    {
       os_page_free(OS_DS_REG ,filep);
       stats->file_objects--;
    }
}

struct file *alloc_file()
{
  
  struct file *file = (struct file *) os_page_alloc(OS_DS_REG); 
  file->fops = (struct fileops *) (file + sizeof(struct file)); 
  bzero((char *)file->fops, sizeof(struct fileops));
  stats->file_objects++;
  return file; 
}

static int do_read_kbd(struct file* filep, char * buff, u32 count)
{
  kbd_read(buff);
  return 1;
}

static int do_write_console(struct file* filep, char * buff, u32 count)
{
  struct exec_context *current = get_current_ctx();
  return do_write(current, (u64)buff, (u64)count);
}

struct file *create_standard_IO(int type)
{
  struct file *filep = alloc_file();
  filep->type = type;
  if(type == STDIN)
     filep->mode = O_READ;
  else
      filep->mode = O_WRITE;
  if(type == STDIN){
        filep->fops->read = do_read_kbd;
  }else{
        filep->fops->write = do_write_console;
  }
  filep->fops->close = generic_close;
  filep->ref_count = 1;
  return filep;
}

int open_standard_IO(struct exec_context *ctx, int type)
{
   int fd = type;
   struct file *filep = ctx->files[type];
   if(!filep){
        filep = create_standard_IO(type);
   }else{
         filep->ref_count++;
         fd = 3;
         while(ctx->files[fd])
             fd++; 
   }
   ctx->files[fd] = filep;
   return fd;
}
/**********************************************************************************/
/**********************************************************************************/
/**********************************************************************************/
/**********************************************************************************/



void do_file_fork(struct exec_context *child)
{
   /*TODO the child fds are a copy of the parent. Adjust the refcount*/
   if(child == NULL)
    return;
   for(int i=0; i<MAX_OPEN_FILES; i++){
     if(child->files[i])
        child->files[i]->ref_count++;
   }

}

void do_file_exit(struct exec_context *ctx)
{
   /*TODO the process is exiting. Adjust the ref_count
     of files*/
    if(ctx == NULL)
      return;
    for(int i=0; i<MAX_OPEN_FILES; i++){
      if (ctx->files[i])
        generic_close(ctx->files[i]);
    }

}

long generic_close(struct file *filep)
{
  /** TODO Implementation of close (pipe, file) based on the type 
   * Adjust the ref_count, free file object
   * Incase of Error return valid Error code 
   * 
   */

    if(filep == NULL)
      return -EINVAL;
    
    filep->ref_count--;
    
    if(filep->ref_count)
      return filep->ref_count;
    else{
        if(filep->type==REGULAR){
            free_file_object(filep);
        }
        else if(filep->type==PIPE){
            
            if(filep->ref_count == 1){
              if(filep->mode == O_READ){
                filep->pipe->is_ropen = 0;

                if(filep->pipe->is_wopen == 0)
                  free_pipe_info(filep->pipe);
              }

              if(filep->mode == O_WRITE){
                filep->pipe->is_wopen = 0;

                if(filep->pipe->is_ropen == 0)
                  free_pipe_info(filep->pipe);
              }
            }

            free_file_object(filep);
        }
        else{
            free_file_object(filep);
        }
        return 0;
    }

    int ret_fd = -EINVAL; 
    return ret_fd;

}

static int do_read_regular(struct file *filep, char * buff, u32 count)
{
   /** TODO Implementation of File Read, 
    *  You should be reading the content from File using file system read function call and fill the buf
    *  Validate the permission, file existence, Max length etc
    *  Incase of Error return valid Error code 
    * */

    if(filep == NULL)
      return -EINVAL;

    if(filep->mode & 0x1){
      int temp = flat_read(filep->inode, buff, count, &(filep->offp));
      filep->offp += temp;
      return temp;
    }
    else
        return -EACCES;

    int ret_fd = -EINVAL; 
    return ret_fd;
}


static int do_write_regular(struct file *filep, char * buff, u32 count)
{
    /** TODO Implementation of File write, 
    *   You should be writing the content from buff to File by using File system write function
    *   Validate the permission, file existence, Max length etc
    *   Incase of Error return valid Error code 
    * */

    if(filep == NULL)
      return -EINVAL;

    if(filep->mode & 0x2){
      int temp = flat_write(filep->inode, buff, count, &(filep->offp));

      if (temp == -1)
        return -1;
        
      filep->offp += temp;
      return temp;
    }
    else
        return -EACCES;

    int ret_fd = -EINVAL; 
    return ret_fd;
}

static long do_lseek_regular(struct file *filep, long offset, int whence)
{
  //Can have error in the setting and returning of offsets.
    /** TODO Implementation of lseek 
    *   Set, Adjust the ofset based on the whence
    *   Incase of Error return valid Error code 
    * */

    if (filep == NULL)
      return -EINVAL;

    if((whence != SEEK_CUR) && (whence != SEEK_END) && (whence != SEEK_SET))
      return -EINVAL;
    
    if((filep->pipe) != NULL)
      return -EOTHERS;

    long int curr_end = (long int)(filep->inode->max_pos);
    long int max_size = (long int)(filep->inode->e_pos - filep->inode->s_pos);

    if(whence == SEEK_SET){
      if((offset<0) || (offset >= max_size))
        return -EINVAL;

        filep->offp = offset;
    }
    if(whence == SEEK_CUR){
      if( (((long int)filep->offp) + offset < 0) || (((long int)filep->offp)+offset>=max_size) )
        return -EINVAL;

      filep->offp = (u32)(((long int)filep->offp)+offset);
    }
    if(whence == SEEK_END){
      if((curr_end + offset < (long int)(filep->inode->s_pos)) || (curr_end+offset >= (long int)(filep->inode->e_pos)) )
        return -EINVAL;

      filep->offp = (u32)((long int)(curr_end - (long int)(filep->inode->s_pos))+offset);
    }

    return filep->offp;

    int ret_fd = -EINVAL; 
    return ret_fd;
}

extern int do_regular_file_open(struct exec_context *ctx, char* filename, u64 flags, u64 mode)
{ 
  /**  TODO Implementation of file open, 
    *  You should be creating file(use the alloc_file function to creat file), 
    *  To create or Get inode use File system function calls, 
    *  Handle mode and flags 
    *  Validate file existence, Max File count is 32, Max Size is 4KB, etc
    *  Incase of Error return valid Error code 
    * */

    if(ctx == NULL)
      return -EINVAL;

    struct inode *new_node = lookup_inode(filename);
    if(new_node){
       if((flags&O_CREAT) == O_CREAT)
        return -EINVAL;
        if((flags&O_READ) && !(new_node->mode&O_READ))
          return -EACCES;
        if((flags&O_WRITE) && !(new_node->mode&O_WRITE))
          return -EACCES;
        if((flags&O_EXEC) && !(new_node->mode&O_EXEC))
          return -EACCES;
        else{
           struct file* filep = alloc_file();
           filep->type = REGULAR;
           filep->mode = mode;
           filep->offp = 0;
           filep->inode = new_node;
           filep->fops->read = do_read_regular;
           filep->fops->write = do_write_regular;
           filep->fops->lseek = do_lseek_regular;
           filep->fops->close = generic_close;
           filep->pipe = NULL;
           
           for(int i=0; i<MAX_OPEN_FILES; i++){
             if(!ctx->files[i]){
               ctx->files[i] = filep;
               filep->ref_count = 1;
               return i;
             }
           }
       }
    }
    else{
        if((flags&O_CREAT) == O_CREAT){
            new_node = create_inode(filename, mode);
               struct file* filep = alloc_file();
               filep->type = REGULAR;
               filep->mode = mode;
               filep->offp = 0;
               filep->inode = new_node;
               filep->fops->read = do_read_regular;
               filep->fops->write = do_write_regular;
               filep->fops->lseek = do_lseek_regular;
               filep->fops->close = generic_close;
               filep->pipe = NULL;
               
               for(int i=0; i<MAX_OPEN_FILES; i++){
                  if(!ctx->files[i]){
                    ctx->files[i] = filep;
                    filep->ref_count = 1;
                    return i;
                  }
                }
        }    
    }

    int ret_fd = -EINVAL; 
    return ret_fd;
}

int fd_dup(struct exec_context *current, int oldfd)
{
     /** TODO Implementation of dup 
      *  Read the man page of dup and implement accordingly 
      *  return the file descriptor,
      *  Incase of Error return valid Error code 
      * */

    if(current == NULL)
      return -EINVAL;

    if((oldfd < 0) || (oldfd >= MAX_OPEN_FILES))
      return -EINVAL;
    
    if(current->files[oldfd] == NULL)
      return -EOTHERS;

    struct file* temp_file = (current->files)[oldfd];
    if(temp_file){
      for(int i=0; i<32; i++){
        if(current->files[i] == NULL){
          current->files[i] = temp_file;
          temp_file->ref_count++;
          return i;
        }
      }
      return -EOTHERS;
    }
    else
      return -EINVAL;

    int ret_fd = -EINVAL; 
    return ret_fd;
}


int fd_dup2(struct exec_context *current, int oldfd, int newfd)
{
  /** TODO Implementation of the dup2 
    *  Read the man page of dup2 and implement accordingly 
    *  return the file descriptor,
    *  Incase of Error return valid Error code 
    * */

    if(current == NULL)
      return -EINVAL;

    if((oldfd < 0) || (oldfd >= MAX_OPEN_FILES))
      return -EINVAL;

    if((newfd < 0) || (newfd >= MAX_OPEN_FILES))
      return -EINVAL;
    
    if(oldfd == newfd)
      return newfd;

    if(current->files[oldfd] == NULL)
      return -EOTHERS;

    struct file* temp_file = (current->files)[oldfd];
    if(temp_file){
      if((current->files)[newfd]!=NULL){
        int gen_close = generic_close(current->files[newfd]);
        if(gen_close != 0)
          return -EOTHERS;
      }
      
      (current->files)[newfd] = temp_file;
      temp_file->ref_count++;

      return newfd;
    }
    else
      return -EINVAL;

    int ret_fd = -EINVAL; 
    return ret_fd;
}
