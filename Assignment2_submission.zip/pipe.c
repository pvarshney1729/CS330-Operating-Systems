#include<pipe.h>
#include<context.h>
#include<memory.h>
#include<lib.h>
#include<entry.h>
#include<file.h>
/***********************************************************************
 * Use this function to allocate pipe info && Don't Modify below function
 ***********************************************************************/
struct pipe_info* alloc_pipe_info()
{
    struct pipe_info *pipe = (struct pipe_info*)os_page_alloc(OS_DS_REG);
    char* buffer = (char*) os_page_alloc(OS_DS_REG);
    pipe ->pipe_buff = buffer;
    return pipe;
}


void free_pipe_info(struct pipe_info *p_info)
{
    if(p_info)
    {
        os_page_free(OS_DS_REG ,p_info->pipe_buff);
        os_page_free(OS_DS_REG ,p_info);
    }
}
/*************************************************************************/
/*************************************************************************/


int pipe_read(struct file *filep, char *buff, u32 count)
{
    /**
    *  TODO:: Implementation of Pipe Read
    *  Read the contect from buff (pipe_info -> pipe_buff) and write to the buff(argument 2);
    *  Validate size of buff, the mode of pipe (pipe_info->mode),etc
    *  Incase of Error return valid Error code 
    */

    if(filep->pipe == NULL || filep == NULL || count < 0 || buff == NULL)
      return -EINVAL;

    if(filep->pipe->is_ropen == 0)
        return -EACCES;

    if((filep->mode & 0x1) && (filep->pipe->is_ropen)){
        u64 i, size ;
        long int buff_size = filep->pipe->buffer_offset;
        int start_read_pos = filep->pipe->read_pos;
        
        size = ( count > buff_size ? buff_size : count );

        if(size > PIPE_MAX_SIZE)
            return -EOTHERS;

        if(size <= 0)
            return 0;

        for( i=0 ; i<size ; i++)
            buff[i] = filep->pipe->pipe_buff[(start_read_pos+i)%4096];
            
        filep->pipe->read_pos = (start_read_pos + size)%4096;
        filep->pipe->buffer_offset -= size;
        
        return size;
    }

    int ret_fd = -EINVAL; 
    return ret_fd;
}


int pipe_write(struct file *filep, char *buff, u32 count)
{
    /**
    *  TODO:: Implementation of Pipe Read
    *  Write the contect from   the buff(argument 2);  and write to buff(pipe_info -> pipe_buff)
    *  Validate size of buff, the mode of pipe (pipe_info->mode),etc
    *  Incase of Error return valid Error code 
    */

    if(filep->pipe == NULL || filep == NULL || count < 0 || buff == NULL)
      return -EINVAL;

    if(filep->pipe->is_wopen == 0)
        return -EACCES;

    if((filep->mode & 0x02) && (filep->pipe->is_wopen)){
        long int buff_size = filep->pipe->buffer_offset;
        long int start_write_pos = filep->pipe->write_pos;

        if (buff_size + count > PIPE_MAX_SIZE)
            return -EOTHERS;

        for(int i=0; i<count; i++)
            filep->pipe->pipe_buff[(start_write_pos + i)%4096] = buff[i];

        filep->pipe->write_pos = (start_write_pos + count)%4096;
        filep->pipe->buffer_offset += count;

        return count;
    }

    int ret_fd = -EINVAL; 
    return ret_fd;
}

int create_pipe(struct exec_context *current, int *fd)
{
    /**
    *  TODO:: Implementation of Pipe Create
    *  Create file struct by invoking the alloc_file() function, 
    *  Create pipe_info struct by invoking the alloc_pipe_info() function
    *  fill the valid file descriptor in *fd param
    *  Incase of Error return valid Error code 
    */

    if(current == NULL)
      return -EINVAL;

    struct file* file1 = alloc_file();
    if(file1 == NULL)
        return -ENOMEM;
    struct file* file2 = alloc_file();
    if(file2 == NULL)
        return -ENOMEM;
    struct pipe_info* new_pipe = alloc_pipe_info();
    if(new_pipe == NULL)
        return -ENOMEM;

    file1->type = PIPE;
    file1->mode = O_READ;
    file1->offp = 0;
    file1->ref_count = 1;
    file1->inode = NULL;
    file1->fops->read = pipe_read;
    file1->fops->close = generic_close;
    file1->pipe = new_pipe;

    file2->type = PIPE;
    file2->mode = O_WRITE;
    file2->offp = 0;
    file2->inode = NULL;
    file2->fops->write = pipe_write;
    file2->fops->close = generic_close;
    file2->pipe = new_pipe;

    new_pipe->read_pos = 0;
    new_pipe->write_pos = 0;
    new_pipe->buffer_offset = 0;
    new_pipe->is_ropen = 1;
    new_pipe->is_wopen = 1;

    for( fd[0]=0; fd[0]<MAX_OPEN_FILES; fd[0]++){
        if(current->files[fd[0]] == NULL)
            break;
    }

    if(fd[0] == MAX_OPEN_FILES)
        return -ENOMEM;

    for( fd[1]=fd[0]+1; fd[1]<MAX_OPEN_FILES; fd[1]++){
        if(current->files[fd[1]] == NULL)
            break;
    }

    if(fd[1] == MAX_OPEN_FILES)
        return -ENOMEM;

    if (fd[0]<MAX_OPEN_FILES && fd[1]<MAX_OPEN_FILES){
        current->files[fd[0]] = file1;
        file1->ref_count = 1;
        current->files[fd[1]] = file2;
        file2->ref_count = 1;

        return 0;
    }

    int ret_fd = -EINVAL; 
    return ret_fd;
}

