//Prateek Varshney 170494

#include <cfork.h>
#include <page.h>
#include <mmap.h>

struct PageLocation {
	int level;
	unsigned long * tbl1_addr;
	unsigned long * tbl2_addr;
	unsigned long * tbl3_addr;
	unsigned long * tbl4_addr;
	unsigned long * page_addr;
};

/* You need to implement cfork_copy_mm which will be called from do_cfork in entry.c. Don't remove copy_os_pts()*/
void cfork_copy_mm(struct exec_context *child, struct exec_context *parent ){

    struct PageLocation *path = os_alloc(sizeof(struct PageLocation));

    void *os_addr;
    u64 virt_addr;
    struct mm_segment *segment;

    child->pgd = os_pfn_alloc(OS_PT_REG);
    os_addr = child->pgd<<PAGE_SHIFT;
    bzero((char *)os_addr, PAGE_SIZE);

    //CODE segment
    segment = &parent->mms[MM_SEG_CODE];
    for(virt_addr = segment->start; virt_addr < segment->next_free; virt_addr += PAGE_SIZE){
        reach_physical_page(path, parent->pgd << PAGE_SHIFT, virt_addr);
        if(path->level != 5)
            continue;

        map_physical_page(child->pgd << PAGE_SHIFT, virt_addr, segment->access_flags, (u32)( path->page_addr) >> PAGE_SHIFT );
        increment_pfn_info_refcount(get_pfn_info((u32)(path->page_addr) >> PAGE_SHIFT ));
    }

    //RODATA segment
    segment = &parent->mms[MM_SEG_RODATA];
    for(virt_addr = segment->start; virt_addr < segment->next_free; virt_addr += PAGE_SIZE){
        reach_physical_page(path, parent->pgd << PAGE_SHIFT, virt_addr);

        if(path->level != 5)
            continue;

        map_physical_page(child->pgd << PAGE_SHIFT, virt_addr, segment->access_flags, (u32)(path->page_addr) >> PAGE_SHIFT );
        increment_pfn_info_refcount(get_pfn_info((u32)(path->page_addr) >> PAGE_SHIFT ));
    }

    //DATA segment
    segment = &parent->mms[MM_SEG_DATA];
    for(virt_addr = segment->start; virt_addr < segment->next_free; virt_addr += PAGE_SIZE){
        reach_physical_page(path, (parent->pgd) << PAGE_SHIFT, virt_addr);

        if(path->level != 5)
           continue;

        u32 permissions = segment->access_flags;
        permissions = permissions & (~MM_WR);
        protect_physical_page((parent->pgd) << PAGE_SHIFT, virt_addr, PROT_READ);

        map_physical_page((child->pgd) << PAGE_SHIFT, virt_addr, permissions ,(u32)(path->page_addr) >> PAGE_SHIFT );
        increment_pfn_info_refcount(get_pfn_info((u32)(path->page_addr) >> PAGE_SHIFT ));
    }

    //STACK segment possibly change this
    segment = &parent->mms[MM_SEG_STACK];
    for(virt_addr = segment->end - PAGE_SIZE; virt_addr >= segment->next_free; virt_addr -= PAGE_SIZE){
        reach_physical_page(path, (parent->pgd) << PAGE_SHIFT, virt_addr);
        if(path->level != 5)
            continue;

        u64 new_page = map_physical_page(child->pgd << PAGE_SHIFT, virt_addr,segment->access_flags, 0 );
        u64 pfn = new_page << PAGE_SHIFT;
        memcpy((char *)pfn, (char *)(path->page_addr), PAGE_SIZE);
    }

    // VM AREA
    for (struct vm_area * cur = parent->vm_area; cur !=  NULL; cur = cur->vm_next) {
        for(unsigned long * i=cur->vm_start; i < cur->vm_end; i += PAGE_SIZE){
        reach_physical_page(path, parent->pgd << PAGE_SHIFT, i);
        if(path->level != 5)
            continue;

        u32 permissions = segment->access_flags;
        permissions = permissions & (~MM_WR);
        protect_physical_page(parent->pgd << PAGE_SHIFT, i, PROT_READ);

        map_physical_page(child->pgd << PAGE_SHIFT, i, permissions, (u32)(path->page_addr) >> PAGE_SHIFT );
        increment_pfn_info_refcount(get_pfn_info((u32)(path->page_addr) >> PAGE_SHIFT ));

       }
    }

    os_free(path,sizeof(path));
    copy_os_pts(parent->pgd, child->pgd);
    return;

    }

/* You need to implement cfork_copy_mm which will be called from do_vfork in entry.c.*/
void vfork_copy_mm(struct exec_context *child, struct exec_context *parent ){

    struct PageLocation *path = os_alloc(sizeof(struct PageLocation));
    struct mm_segment *segment;
    segment = &parent->mms[MM_SEG_STACK];
    child->pgd = parent->pgd;

  	u64 offset = segment->end-parent->regs.rbp;
	u64 initial_stack_size = (segment->end-parent->regs.rbp);
	u64 final_stack_size = 2*initial_stack_size;
	u64 initial_no_of_pages_in_stack = (final_stack_size)/PAGE_SIZE;
	u64 final_no_of_pages_in_stack = (final_stack_size)/PAGE_SIZE;
	if((2*initial_stack_size)%(PAGE_SIZE)!=0) {
		final_no_of_pages_in_stack++;
		initial_no_of_pages_in_stack++;
	}

	u64 current_allocated_pages = (segment->end-segment->next_free)/PAGE_SIZE;
	u64 new_pages_to_alloc = final_no_of_pages_in_stack-current_allocated_pages;
	int flag = 1;

	if (new_pages_to_alloc <= 0)
        flag = 0;

	if (flag)
        segment->next_free=segment->next_free-new_pages_to_alloc*PAGE_SIZE;

	u64 virt_addr = (u64)(segment->next_free) - PAGE_SIZE;
	for(int i = 0; i < new_pages_to_alloc; i++){
		reach_physical_page(path, parent->pgd << PAGE_SHIFT, virt_addr);
		if(path->level == 5)
			map_physical_page(parent->pgd << PAGE_SHIFT, virt_addr, segment->access_flags, 0);

		virt_addr -= PAGE_SIZE;
	}

	for(u64 i = (segment->end) - 8; i >= parent->regs.rbp; i -= 0x8)
		memcpy((char *)(i-offset), (char *)(i), 0x8);

	u64 current_add = parent->regs.rbp;

	while(current_add != segment->end - 0x8){
	    u64 current_val = *(u64 *)(current_add);
	    *(u64 *)(current_add - offset) -= offset;
	    current_add = current_val;
	}

 	child->regs.entry_rsp -= offset;
	child->regs.rbp -= offset;
	parent->state = WAITING;

	os_free(path,sizeof(path));

    return;

}

/*You need to implement handle_cow_fault which will be called from do_page_fault
incase of a copy-on-write fault

* For valid acess. Map the physical page
 * Return 1
 *
 * For invalid access,
 * Return -1.
*/

int handle_cow_fault(struct exec_context *current, u64 cr2){
    const unsigned long PERM_FLAG = 2;

    struct PageLocation *path = os_alloc(sizeof(struct PageLocation));
    reach_physical_page(path, current->pgd << PAGE_SHIFT, cr2);

    unsigned long offset_4 = ((cr2 & PTE_MASK) >> PTE_SHIFT);
    if (path->level != 5) {
        os_free(path,sizeof(path));
        return 0;
    }

    unsigned long perm_r = ((unsigned long)(path->tbl4_addr + offset_4)&PERM_FLAG);
    unsigned long perm_v;
    int valid = 0;
    u32 permissions = 0;

    for (int i = 0; i < MAX_MM_SEGS; i++) {
        if ((cr2 >= current->mms[i].start) && (cr2 < current->mms[i].end)){
            valid = 1;
            perm_v = (current->mms[i].access_flags)&PERM_FLAG;
            permissions = current->mms[i].access_flags;
            break;
        }
    }

    if(valid == 0) {
    	if(current->vm_area != NULL){
    		for (struct vm_area* curr_node = current->vm_area; curr_node != NULL; curr_node = curr_node->vm_next) {
    			if ((curr_node->vm_start <= cr2) && (curr_node->vm_end > cr2)) {
    			valid = 1;
    			perm_v = (curr_node->access_flags)&PERM_FLAG;
    			permissions = curr_node->access_flags;
    	        }
            }
    	}
    }

    if(valid == NULL) {
        os_free(path, sizeof(path));
        return -1;
    }

    if (perm_v) {
        struct pfn_info* pfn = get_pfn_info(((unsigned long)path->page_addr) >> PAGE_SHIFT);
        if (get_pfn_info_refcount(pfn) > 1) {
            u64 new_page_pfn = (unsigned long *)map_physical_page(current->pgd << PAGE_SHIFT, cr2, permissions, NULL) ;
            u64 naddr = (u64)osmap(new_page_pfn);
            memcpy((char *)naddr,(char *)(path->page_addr), PAGE_SIZE);

            decrement_pfn_info_refcount(pfn);
            os_free(path,sizeof(path));
            return 1;
        }

        else {
            protect_physical_page(current->pgd << PAGE_SHIFT, cr2, PROT_READ|PROT_WRITE, 0);
            os_free(path,sizeof(path));
            return 1;
        }
    }

    return 0;
}

/* You need to handle any specific exit case for vfork here, called from do_exit*/
void vfork_exit_handle(struct exec_context *ctx){
    struct exec_context *parent = get_ctx_by_pid(ctx->ppid);
    struct mm_segment *segment;
    segment = &parent->mms[MM_SEG_STACK];

    if(parent!=NULL && parent->state == WAITING){
    	parent->state = READY;
    	parent->vm_area = ctx->vm_area;
    	for(int i = 0; i < MAX_MM_SEGS - 1; i++)
    		parent->mms[i]=ctx->mms[i];

        //dealloc child stack
        u64 parent_pages = (segment->end - parent->regs.rbp)/PAGE_SIZE;
        if(((segment->end - parent->regs.rbp)%PAGE_SIZE) !=0)
            parent_pages++;

        u64 child_pages = (segment->end - segment->next_free)/PAGE_SIZE;
        u64 dealloc_pages = child_pages - parent_pages;
        for(u64 i = 0; i < dealloc_pages; i++){
        	do_unmap_user(ctx, segment->next_free);
        	segment->next_free = segment->next_free + PAGE_SIZE;
        }
    }

    return ;
}
