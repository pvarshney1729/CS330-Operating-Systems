//Prateek Varshney 170494

#include <types.h>
#include <mmap.h>

#ifndef PAGE_MASK
#define PAGE_MASK (~(0xfffUL))
#endif
/**
 * Function will invoked whenever there is page fault. (Lazy allocation)
 *
 * For valid acess. Map the physical page
 * Return 1
 *
 * For invalid access,
 * Return -1.
 */

 int vm_area_pagefault(struct exec_context *current, u64 addr, int error_code)
 {
 	struct vm_area *head = current->vm_area;
    struct vm_area *curr_node = head;

 	if (head == NULL)
 		return -1;

 	while (curr_node->vm_end <= addr){
 		curr_node = curr_node->vm_next;
 		if (curr_node == NULL)
 			return -1;
 	}

 	if (curr_node->vm_start > addr)
 		return -1;

 	if (error_code&2){
 		if (curr_node->access_flags & 2){
 			map_physical_page(current->pgd << 12, addr, curr_node->access_flags, 0);
 			return 1;
 		}
 		return -1;
 	}

 	if (error_code&4){
 		if (curr_node->access_flags & 4){
 			map_physical_page(current->pgd << 12, addr, curr_node->access_flags, 0);
 			return 1;
 		}
 		return -1;
 	}

 	return -1;
 }


struct PageLocation
{
	int level;
	unsigned long *tbl1_addr;
	unsigned long *tbl2_addr;
	unsigned long *tbl3_addr;
	unsigned long *tbl4_addr;
	unsigned long *page_addr;
};

void reach_physical_page(struct PageLocation * path , unsigned long base, u64 address)
{
	void *os_addr;
	u64 pfn;
	path->level = 0;
	path->tbl1_addr = 0;
	path->tbl2_addr = 0;
	path->tbl3_addr = 0;
	path->tbl4_addr = 0;
	path->page_addr = 0;
	path->tbl1_addr = base&FLAG_MASK;

	unsigned long *ptep = (unsigned long *)base + ((address&PGD_MASK) >> PGD_SHIFT);
	path->tbl1_addr = base;

    if (!(*ptep)){
		path->level = 1;
		return ;
	}

	else
		os_addr = (void *)((*ptep) & FLAG_MASK);

	path->tbl2_addr = os_addr;
	ptep = (unsigned long *)os_addr + ((address & PUD_MASK) >> PUD_SHIFT);
	if (!*ptep){
		path->level = 2;
		return ;
	}

	else
		os_addr = (void *)((*ptep) & FLAG_MASK);

	path->tbl3_addr = os_addr;
	ptep = (unsigned long *)os_addr + ((address & PMD_MASK) >> PMD_SHIFT);
	if (!*ptep){
		path->level = 3;
		return ;
	}
	else
		os_addr = (void *)((*ptep) & FLAG_MASK);

	path->tbl4_addr = os_addr;
	ptep = (unsigned long *)os_addr + ((address & PTE_MASK) >> PTE_SHIFT);
	if (!*ptep){
		path->level = 4;
		return ;
	}
	else
		os_addr = (void *)((*ptep) & FLAG_MASK);

	path->page_addr = os_addr;
	path->level = 5;

	return ;
}


u32 protect_physical_page(unsigned long base, u64 address, u32 prot)
{
	struct PageLocation *path = os_alloc(sizeof(struct PageLocation));
	 reach_physical_page(path, base, address);

    if (path->level != 5){
		os_free(path,sizeof(path));
		return -1;
	}

	unsigned long *ptep = (unsigned long *)(path->tbl4_addr) + ((address & PTE_MASK) >> PTE_SHIFT);
	if (!(prot&MM_WR))
		*ptep = *ptep&(~MM_WR);
	else
		*ptep = *ptep | MM_WR;

	os_free(path,sizeof(path));
	asm volatile("mov	%%cr3,%%eax;"
				 "mov	%%eax,%%cr3;"
				 :
				 :);
	return 1;
}


u32 delete_physical_page(unsigned long base, u64 address)
{
	struct PageLocation *path = os_alloc(sizeof(struct PageLocation));
	reach_physical_page(path, base, address);

	if (path->level != 5){
		os_free(path, sizeof(struct PageLocation));
		return -1;
	}

	u64 pfn = (unsigned long)(path->page_addr) >> PAGE_SHIFT;
	os_pfn_free(USER_REG, pfn);
	*((unsigned long *)path->tbl4_addr + ((address & PGD_MASK) >> PGD_SHIFT)) = 0;

	int flag = 1;
	for (u64 i = 0; i < 512; i++){
		if ((*((unsigned long *)path->tbl4_addr + i)) != 0)
			flag = 0;
	}

	pfn = (unsigned long)(path->tbl4_addr) >> PAGE_SHIFT;
	if (flag == 0){
		os_free(path, sizeof(struct PageLocation));
    	asm volatile("mov	%%cr3,%%eax;"
    			 "mov	%%eax,%%cr3;"
    			 :
    			 :);
		return 1;
	}

	os_pfn_free(OS_PT_REG, pfn);
	*((unsigned long *)path->tbl3_addr + ((address & PUD_MASK) >> PUD_SHIFT)) = 0;

	flag = 1;
	for (u64 i = 0; i < 512; i++){
		if ((*((unsigned long *)path->tbl3_addr + i)) != 0)
			flag = 0;
	}

	pfn = (unsigned long)(path->tbl3_addr) >> PAGE_SHIFT;
	if (flag == 0){
		os_free(path,sizeof(struct PageLocation));
        asm volatile("mov	%%cr3,%%eax;"
        				 "mov	%%eax,%%cr3;"
        				 :
        				 :);
		return 1;
	}

	os_pfn_free(OS_PT_REG, pfn);
	*((unsigned long *)path->tbl2_addr + ((address & PMD_MASK) >> PMD_SHIFT)) = 0;

	flag = 1;
	for (u64 i = 0; i < 512; i++){
		if ((*((unsigned long *)path->tbl2_addr + i)) != 0)
			flag = 0;
	}

	pfn = (unsigned long)(path->tbl2_addr) >> PAGE_SHIFT;
	if (flag == 0){
		os_free(path,sizeof(struct PageLocation));
        asm volatile("mov	%%cr3,%%eax;"
    				 "mov	%%eax,%%cr3;"
    				 :
    				 :);
		return 1;
	}

	os_pfn_free(OS_PT_REG, pfn);
	*((unsigned long *)path->tbl1_addr + ((address & PTE_MASK) >> PTE_SHIFT)) = 0;

    os_free(path,sizeof(path));
    asm volatile("mov	%%cr3,%%eax;"
				 "mov	%%eax,%%cr3;"
				 :
				 :);
	return 1;
}


int vm_area_unmap_virt(struct exec_context *current, u64 addr, int length)
{
	if (addr >= MMAP_AREA_END || addr < MMAP_AREA_START)
		return -1;

	u64 no_of_pages = ((u64)length / PAGE_SIZE);
	if (length % PAGE_SIZE != 0)
		no_of_pages++;

	u64 size_to_unmap = no_of_pages * PAGE_SIZE;

    struct vm_area* head = current->vm_area;
	struct vm_area *curr_node = head;
	struct vm_area *prev_node = NULL;
	u64 end_addr = addr + size_to_unmap;

	if (curr_node == NULL)
		return 0;

	while (curr_node->vm_end <= addr){
		prev_node = curr_node;
		curr_node = curr_node->vm_next;
		if (curr_node == NULL)
			break;
	}

	if (curr_node == NULL)
		return 0;

	while (curr_node->vm_start < end_addr){
		if (curr_node->vm_start >= addr){

			if (curr_node->vm_end <= end_addr){

				if (prev_node == NULL){
					current->vm_area = curr_node->vm_next;
					dealloc_vm_area(curr_node);
					curr_node = curr_node->vm_next;
				}

				else {
					prev_node->vm_next = curr_node->vm_next;
					dealloc_vm_area(curr_node);
					curr_node=curr_node->vm_next;
				}
			}

			else
				curr_node->vm_start = end_addr;
		}
		else{
			if (curr_node->vm_end > end_addr){
				struct vm_area *temp = curr_node->vm_next;
				if (stats->num_vm_area == 128)
                    return -1;

				curr_node->vm_next = alloc_vm_area();
				curr_node->vm_next->vm_start = end_addr;
				curr_node->vm_next->vm_end = curr_node->vm_end;
				curr_node->vm_end = addr;
				curr_node->vm_next->access_flags = curr_node->access_flags;
				curr_node->vm_next->vm_next = temp;
			}

			else {
				curr_node->vm_end = addr;
				prev_node=curr_node;
				curr_node = curr_node->vm_next;
			}
		}

		if (curr_node == NULL)
			break;
	}

	return 0;
}


long vm_area_map_virt(struct exec_context *current, u64 addr, int length, int prot, int flags)
{
	if (length < 0)
        return -1;

	u64 no_of_pages = ((u64)length / PAGE_SIZE);
	if (length % PAGE_SIZE != 0)
		no_of_pages++;

	u64 size_to_alloc = no_of_pages * PAGE_SIZE;

	struct vm_area *head = current->vm_area;
	struct vm_area *curr_node = head;

	long ret_addr = -1;

	if (addr == NULL){
		if (head == NULL){
			if (MMAP_AREA_START + size_to_alloc > MMAP_AREA_END)
				return -1;

			if (stats->num_vm_area==128)
                return -1;

			current->vm_area = alloc_vm_area();
			current->vm_area->vm_start = MMAP_AREA_START;
			current->vm_area->vm_end = MMAP_AREA_START + size_to_alloc;
			current->vm_area->access_flags = prot;
			current->vm_area->vm_next = NULL;
			ret_addr = MMAP_AREA_START;
		}

		else{
			u64 prev_node_end = MMAP_AREA_START;
			u64 next_node_start = curr_node->vm_start;
			struct vm_area *prev_node = NULL;

			while (next_node_start - prev_node_end < size_to_alloc){
				prev_node_end = curr_node->vm_end;
                if (curr_node->vm_next == NULL)
                    next_node_start = MMAP_AREA_END;
                else
                    next_node_start = curr_node->vm_next->vm_start;

				prev_node = curr_node;
				curr_node = curr_node->vm_next;
				if (curr_node == NULL)
					break;
			}

			if (prev_node == NULL){
				if ((curr_node->vm_start - MMAP_AREA_START == size_to_alloc) && (curr_node->access_flags == prot)){
					curr_node->vm_start = MMAP_AREA_START;
					ret_addr = MMAP_AREA_START;
				}

				else{
                    if(stats->num_vm_area == 128)
                        return -1;

					current->vm_area = alloc_vm_area();
					current->vm_area->vm_start = MMAP_AREA_START;
					current->vm_area->vm_end = MMAP_AREA_START + size_to_alloc;
					current->vm_area->access_flags = prot;
					current->vm_area->vm_next = curr_node;
					ret_addr = MMAP_AREA_START;
				}
			}

			else if (curr_node == NULL){
				if (MMAP_AREA_END - prev_node->vm_end < size_to_alloc)
					return -1;

				else if (prot == prev_node->access_flags){
					ret_addr = prev_node->vm_end;
					prev_node->vm_end = prev_node->vm_end + size_to_alloc;
				}

				else{
                    if(stats->num_vm_area == 128)
                        return -1;

					prev_node->vm_next = alloc_vm_area();
					prev_node->vm_next->vm_start = prev_node->vm_end;
					prev_node->vm_next->vm_end = prev_node->vm_end + size_to_alloc;
					prev_node->vm_next->access_flags = prot;
					prev_node->vm_next->vm_next = NULL;
					ret_addr = prev_node->vm_end;
				}
			}

			else{
				if (curr_node->vm_start - prev_node->vm_end != size_to_alloc){
					if (prot == prev_node->access_flags){
						ret_addr = prev_node->vm_end;
						prev_node->vm_end = prev_node->vm_end + size_to_alloc;
					}

					else{
                        if(stats->num_vm_area == 128)
                            return -1;

						prev_node->vm_next = alloc_vm_area();
						prev_node->vm_next->vm_start = prev_node->vm_end;
						prev_node->vm_next->vm_end = prev_node->vm_end + size_to_alloc;
						prev_node->vm_next->access_flags = prot;
						prev_node->vm_next->vm_next = curr_node;
						ret_addr = prev_node->vm_end;
					}
				}

				else{
					if (prev_node->access_flags == prot){
						ret_addr = prev_node->vm_end;
						prev_node->vm_end = prev_node->vm_end + size_to_alloc; //merge

						if (curr_node->access_flags == prot){
							prev_node->vm_end = curr_node->vm_end;
							prev_node->vm_next = curr_node->vm_next;
							dealloc_vm_area(curr_node);
						}
					}

					else{
						if (prot == curr_node->access_flags){
							curr_node->vm_start = prev_node->vm_end;
							ret_addr = curr_node->vm_start;
						}

						else{
                            if (stats->num_vm_area==128)
                                return -1;

							prev_node->vm_next = alloc_vm_area();
							prev_node->vm_next->vm_start = prev_node->vm_end;
							prev_node->vm_next->vm_end = prev_node->vm_end + size_to_alloc;
							prev_node->vm_next->access_flags = prot;
							prev_node->vm_next->vm_next = curr_node;
							ret_addr = prev_node->vm_end;
						}
					}
				}
			}
		}
	}

	else{
		if (curr_node == NULL){
			if (addr + size_to_alloc > MMAP_AREA_END)
				ret_addr = vm_area_map_virt(current, NULL, length, prot, flags);

			else{
                if (stats->num_vm_area == 128)
                    return -1;

				current->vm_area = alloc_vm_area();
				current->vm_area->vm_start = addr;
				current->vm_area->vm_end = addr + size_to_alloc;
				current->vm_area->access_flags = prot;
				current->vm_area->vm_next = NULL;
				ret_addr = addr;
			}
		}
		else {
			struct vm_area *prev_node = NULL;
			int overlap = 0;

			while (curr_node->vm_end <= addr){
				prev_node = curr_node;
				curr_node = curr_node->vm_next;
				if (curr_node == NULL)
					break;
			}

			if (curr_node && (curr_node->vm_start < addr + size_to_alloc))
				overlap = 1;

			if (overlap == 1 && (flags&MAP_FIXED))
				return -1;

			if (overlap == 0){
				if (prev_node == NULL){
					if ((curr_node != NULL) && (curr_node->access_flags == prot) && (curr_node->vm_start == addr + size_to_alloc)){
						curr_node->vm_start = addr;
						return addr;
					}

					else {
                        if(stats->num_vm_area == 128)
                            return -1;

						current->vm_area = alloc_vm_area();
						current->vm_area->vm_start = addr;
						current->vm_area->vm_end = addr + size_to_alloc;
						current->vm_area->access_flags = prot;
						current->vm_area->vm_next = curr_node;
						return addr;
					}
				}

				if ((prev_node->vm_end == addr) && (prev_node->access_flags == prot)){
					prev_node->vm_end = addr + size_to_alloc;

					if ((curr_node != NULL) && (prev_node->vm_end == curr_node->vm_start) && (curr_node->access_flags == prot)){
						prev_node->vm_end = curr_node->vm_end;
						prev_node->vm_next = curr_node->vm_next;
						dealloc_vm_area(curr_node);
					}

					ret_addr = addr;
				}

				else{
					if ((curr_node != NULL) && (curr_node->vm_start == addr + size_to_alloc) && (prot == curr_node->access_flags)){
						curr_node->vm_start = addr;
						ret_addr = addr;
					}

					else
					{	if(stats->num_vm_area == 128)
                            return -1;

						prev_node->vm_next = alloc_vm_area();
						prev_node->vm_next->vm_start = addr;
						prev_node->vm_next->vm_end = addr + size_to_alloc;
						prev_node->vm_next->access_flags = prot;
						prev_node->vm_next->vm_next = curr_node;
						ret_addr = addr;
					}
				}

				return ret_addr;
			}

			if (curr_node == NULL)
			{
				if (prev_node->vm_end + size_to_alloc > MMAP_AREA_END)
					ret_addr = vm_area_map_virt(current, 0, length, prot, flags);

                else{
                    if (stats->num_vm_area == 128)
                        return -1;

					prev_node->vm_next = alloc_vm_area();
					prev_node->vm_next->vm_start = prev_node->vm_end;
					prev_node->vm_next->vm_end = prev_node->vm_end + size_to_alloc;
					prev_node->vm_next->access_flags = prot;
					prev_node->vm_next->vm_next = NULL;
					ret_addr = prev_node->vm_end;
				}
			}

			else {
                u64 prev_node_end, next_node_start;
                if (prev_node == NULL)
                    prev_node_end = MMAP_AREA_START;
                else
                    prev_node_end = prev_node->vm_end;

                if (curr_node == NULL)
                    next_node_start = MMAP_AREA_END;
                else
                    next_node_start = curr_node->vm_start;

                while (next_node_start - prev_node_end < size_to_alloc){
					prev_node = curr_node;
					curr_node = curr_node->vm_next;

                    if (curr_node == NULL){
						prev_node_end = prev_node->vm_end;
						next_node_start = MMAP_AREA_END;
						break;
					}

					prev_node_end = prev_node->vm_end;
					next_node_start = curr_node->vm_start;
				}

				if (prev_node == NULL){
					if ((next_node_start - prev_node_end == size_to_alloc) && (curr_node->access_flags == prot)){
						curr_node->vm_start = prev_node_end;
						ret_addr = prev_node_end;
					}

					else{
						if (stats->num_vm_area == 128)
                            return -1;

						current->vm_area = alloc_vm_area();
						current->vm_area->vm_start = prev_node_end;
						current->vm_area->vm_end = prev_node_end + size_to_alloc;
						current->vm_area->access_flags = prot;
						current->vm_area->vm_next = curr_node; //change head
						ret_addr = prev_node_end;
					}
				}

				else if (curr_node == NULL){
					if (next_node_start - prev_node_end < size_to_alloc)
						ret_addr = vm_area_map_virt(current, 0, size_to_alloc, prot, flags);

					if (prot == prev_node->access_flags){
						ret_addr = prev_node->vm_end;
						prev_node->vm_end = prev_node->vm_end + size_to_alloc;
					}

					else {
                        if (stats->num_vm_area == 128)
                            return -1;

						prev_node->vm_next = alloc_vm_area();
						prev_node->vm_next->vm_start = prev_node->vm_end;
						prev_node->vm_next->vm_end = prev_node->vm_end + size_to_alloc;
						prev_node->vm_next->access_flags = prot;
						prev_node->vm_next->vm_next = NULL;
						ret_addr = prev_node->vm_end;
					}
				}

				else{
					if (next_node_start - prev_node_end > size_to_alloc){
						if (prev_node->access_flags == prot){
							ret_addr = prev_node->vm_end;
							prev_node->vm_end = prev_node->vm_end + size_to_alloc; //merge
						}

						else {
                            if (stats->num_vm_area == 128)
                                return -1;

							prev_node->vm_next = alloc_vm_area();
							prev_node->vm_next->vm_start = prev_node->vm_end;
							prev_node->vm_next->vm_end = prev_node->vm_end + size_to_alloc;
							prev_node->vm_next->access_flags = prot;
							prev_node->vm_next->vm_next = curr_node;
							ret_addr = prev_node->vm_end;
						}
					}

					else if (next_node_start - prev_node_end == size_to_alloc)
					{
						if (prev_node->access_flags == prot){
							ret_addr = prev_node->vm_end;
							prev_node->vm_end = prev_node->vm_end + size_to_alloc;

							if (curr_node->access_flags == prot){
								prev_node->vm_end = curr_node->vm_end;
								prev_node->vm_next = curr_node->vm_next;
								dealloc_vm_area(curr_node);
							}
						}

						else{
							if (curr_node->access_flags == prot){
								curr_node->vm_start = prev_node->vm_end;
								ret_addr = curr_node->vm_start;
							}

							else{
                                if(stats->num_vm_area == 128)
                                    return -1;

                                prev_node->vm_next = alloc_vm_area();
								prev_node->vm_next->vm_start = prev_node->vm_end;
								prev_node->vm_next->vm_end = prev_node->vm_end + size_to_alloc;
								prev_node->vm_next->access_flags = prot;
								prev_node->vm_next->vm_next = curr_node;
								ret_addr = prev_node->vm_end;
							}
						}
					}

					else
						ret_addr = vm_area_map_virt(current, 0, length, prot, flags);
				}
			}
		}
	}

	return ret_addr;
}
/**
 * munmap system call implemenations
 */

int vm_area_mprotect_virtual(struct exec_context *current, u64 addr, int length, int prot)
{
	u64 no_of_pages = ((u64)length / PAGE_SIZE);
	if (length % PAGE_SIZE != 0)
		no_of_pages++;
	u64 size_to_modify = no_of_pages * PAGE_SIZE;

    struct vm_area *head = current->vm_area;
	struct vm_area *curr_node = head;

	if (head == NULL)
		return -1;

	while (curr_node->vm_end <= addr){
		curr_node = curr_node->vm_next;
		if (curr_node == NULL)
			break;
	}

	if (curr_node == NULL)
		return -1;

	if (curr_node->vm_start > addr)
		return -1;

	while (curr_node->vm_end <= addr){
		if (curr_node->vm_end != curr_node->vm_next->vm_start)
			return -1;

		curr_node = curr_node->vm_next;
		if (curr_node == NULL)
			return -1;
	}

	curr_node = current->vm_area;

	while (curr_node->vm_end <= addr){
		curr_node = curr_node->vm_next;
		if (curr_node == NULL)
			return -1;
	}

	if((stats->num_vm_area == 127) && (curr_node->vm_start < addr) && (curr_node->vm_end > addr + size_to_modify) && (curr_node->access_flags != prot))
		return -1;

	if(stats->num_vm_area==128)
        return -1;

	u64 flag_map = vm_area_unmap_virt(current, addr, size_to_modify);
	u64 flag_unmap = vm_area_map_virt(current, addr, size_to_modify, prot, 0);

    return 0;
}


long vm_area_map(struct exec_context *current, u64 addr, int length, int prot, int flags)
{
	u64 no_of_pages = ((u64)length / PAGE_SIZE);
	if (length % PAGE_SIZE != 0)
		no_of_pages++;

	long ret_addr = vm_area_map_virt(current, addr, length, prot, flags);
	if (ret_addr < 0)
		return -1;

	if (flags&MAP_POPULATE){
		for (u64 i = 0; i < no_of_pages; i++)
			map_physical_page(current->pgd << PAGE_SHIFT, ret_addr + (i << PAGE_SHIFT), prot, 0);
	}

	return ret_addr;
}


int vm_area_mprotect(struct exec_context *current, u64 addr, int length, int prot)
{
	u64 no_of_pages = ((u64)length / PAGE_SIZE);
	if (length % PAGE_SIZE != 0)
		no_of_pages++;

	u64 size_to_modify = no_of_pages * PAGE_SIZE;

	struct vm_area *curr_node = current->vm_area;

	int ret_addr = vm_area_mprotect_virtual(current, addr, length, prot);
	if (ret_addr < 0)
		return -1;

	u64 end_addr = addr + (no_of_pages << PAGE_SHIFT);
	for(u64 i = addr; i <= (end_addr - PAGE_SIZE); i += PAGE_SIZE){
        u64 * ptep = get_user_pte(current,i,0);
        if((ptep)){
            if(prot & MM_WR)
                *ptep |= 0x2;
            else
                *ptep &= ~0x2;

            asm volatile("mov	%%cr3,%%eax;"
                         "mov	%%eax,%%cr3;"
                         :
                         :);
        }
    }

	return 0;
}


int vm_area_unmap(struct exec_context *current, u64 addr, int length)
{
	u64 no_of_pages = ((u64)length / PAGE_SIZE);
	if (length % PAGE_SIZE != 0)
		no_of_pages++;
	u64 size_to_unmap = no_of_pages * PAGE_SIZE;

    struct vm_area *head = current->vm_area;
	struct vm_area *curr_node = head;
	struct vm_area *prev_node = NULL;
	u64 end_addr = addr + size_to_unmap;

	int ret_addr = vm_area_unmap_virt(current, addr, length);
	if (ret_addr < 0)
		return -1;

	for (u64 i = 0; i < no_of_pages; i++)
		do_unmap_user(current, addr + (i << PAGE_SHIFT));

	return 1;
}
