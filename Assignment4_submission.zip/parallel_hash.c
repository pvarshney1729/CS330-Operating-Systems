#include "common.h"

/*Function templates. TODO*/

static int atomic_add(long *ptr, long val)
{
        int ret = 0;

        asm volatile(
            "lock add %%rsi, (%%rdi);"
            "pushf;"
            "pop %%rax;"
            "movl %%eax, %0;"
            : "=r" (ret)
            :
            : "memory", "rax"
        );


        if(ret & 0x80)
            ret = -1;
        else if(ret & 0x40)
            ret = 0;
        else
            ret = 1;

        return ret;
}

void done_one(struct input_manager *in, int tnum)
{
    int rc = pthread_mutex_lock(&(in->lock));
    assert(rc == 0);

    in->being_processed[tnum] = NULL;
    pthread_cond_broadcast(&(in->cond));

    rc = pthread_mutex_unlock(&(in->lock));
    assert(rc == 0);

    return;
}

int read_op(struct input_manager *in, op_t *op, int tnum)
{
    int rc = pthread_mutex_lock(&(in->lock));
    assert(rc == 0);

    unsigned size = sizeof(op_t);
    memcpy(op, in->curr, size - sizeof(unsigned long));
    if((op->op_type == GET) || (op->op_type == DEL))
       in->curr += size - sizeof(op->datalen) - sizeof(op->data);

    else if(op->op_type == PUT){
       in->curr += size - sizeof(op->data);
       op->data = in->curr;
       in->curr += op->datalen;
    }

    else
       assert(0);

    if(in->curr > in->data + in->size){
        rc = pthread_mutex_unlock(&(in->lock));
        assert(rc == 0);
        return -1;
    }

    //int try = 1, temp = 0;

    in->being_processed[tnum] = op;

    // for(int i = 0; i < THREADS; i++){
    //    if((in->being_processed[i]) && ((in->being_processed[i])->key == op->key) ){
    //        try = 0;
    //        break;
    //    }
    // }
    int i = 0;
    while (i < THREADS){
        if ((i != tnum) && (in->being_processed[i]) && (op->id > in->being_processed[i]->id) && ((in->being_processed[i])->key == op->key)){
            pthread_cond_wait(&(in->cond), &(in->lock));
            i--;
        }
        i++;
    }

    // if(try == 0)
    //    pthread_cond_wait(&(in->cond),&(in->lock));

    rc = pthread_mutex_unlock(&(in->lock));
    assert(rc == 0);

    return 0;
  //return -1;    // Failed
}

int lookup(hash_t *h, op_t *op)
{
    unsigned hashval = hashfunc(op->key, h->table_size);
    hash_entry_t *entry = h->table + hashval;

    unsigned ctr = hashval;

    while(1){
        int rc = pthread_mutex_lock(&(entry->lock));
        assert(rc == 0);

        if(!((entry->key || entry->id == (unsigned)(-1)) && (entry->key != op->key) && (ctr != hashval - 1)))
            break;

        ctr = (ctr + 1) % h->table_size;

        rc = pthread_mutex_unlock(&(entry->lock));
        assert(rc == 0);

        entry = h->table + ctr;
    }

    if(entry->key == op->key){
        op->datalen = entry->datalen;
        op->data = entry->data;

        int rc = pthread_mutex_unlock(&(entry->lock));
        assert(rc == 0);

        return 0;
    }

    int rc = pthread_mutex_unlock(&(entry->lock));
    assert(rc == 0);

    return -1;    // Failed
}

int insert_update(hash_t *h, op_t *op)
{
    unsigned hashval = hashfunc(op->key, h->table_size);
    hash_entry_t *entry = h->table + hashval;

    assert((h) && (h->used < h->table_size));
    assert(op && (op->key));

    unsigned ctr = hashval;
    int rc;

    while(1){
        rc = pthread_mutex_lock(&(entry->lock));
        assert(rc == 0);

        if(!(entry->key && (entry->key != op->key) && (ctr != hashval - 1)))
            break;

        ctr = (ctr + 1) % h->table_size;

        rc = pthread_mutex_unlock(&(entry->lock));
        assert(rc == 0);

        entry = h->table + ctr;
    }

    assert(ctr != hashval - 1);

    if(entry->key == op->key){
        entry->id = op->id;
        entry->datalen = op->datalen;
        entry->data = op->data;

        rc = pthread_mutex_unlock(&(entry->lock));
        assert(rc == 0);

        return 0;
    }

    assert(!(entry->key));

    entry->id = op->id;
    entry->datalen = op->datalen;
    entry->key = op->key;
    entry->data = op->data;

    rc = pthread_mutex_unlock(&(entry->lock));
    assert(rc == 0);

    atomic_add(&(h->used),1);

    return 0;
    //return -1;    // Failed
}

int purge_key(hash_t *h, op_t *op)
{
    unsigned hashval = hashfunc(op->key, h->table_size);
    hash_entry_t *entry = h->table + hashval;
    int rc;
    unsigned ctr = hashval;

    while(1){
        rc = pthread_mutex_lock(&(entry->lock));
        assert(rc == 0);

        if(!((entry->key || entry->id == (unsigned)(-1)) && (entry->key != op->key) && (ctr != hashval - 1)))
           break;

        ctr = (ctr + 1) % h->table_size;

        rc = pthread_mutex_unlock(&(entry->lock));
        assert(rc == 0);

        entry = h->table + ctr;
    }

    if(entry->key == op->key){
        entry->id = (unsigned) -1;
        entry->key = 0;
        entry->datalen = 0;
        entry->data = NULL;

        rc = pthread_mutex_unlock(&(entry->lock));
        assert(rc == 0);

        atomic_add(&(h->used),-1);

        return 0;
    }

    rc = pthread_mutex_unlock(&(entry->lock));
    assert(rc == 0);

    return -1;    // Bogus purge
}
