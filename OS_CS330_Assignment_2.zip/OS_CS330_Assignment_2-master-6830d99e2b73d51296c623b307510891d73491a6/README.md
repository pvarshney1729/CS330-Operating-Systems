Please refer to the documentation directory for details regarding the assignment.
Source code is in "src" directory 
