#include "common.h"

/*Function templates. TODO*/

void done_one(struct input_manager *in, int tnum)
{
   return;
}

int read_op(struct input_manager *in, op_t *op, int tnum)
{
  return -1;    // Failed
}

int lookup(hash_t *h, op_t *op)
{
 
  return -1;    // Failed
}

int insert_update(hash_t *h, op_t *op)
{
   
  return -1;    // Failed
}

int purge_key(hash_t *h, op_t *op)
{
  return -1;    // Bogus purge
}
